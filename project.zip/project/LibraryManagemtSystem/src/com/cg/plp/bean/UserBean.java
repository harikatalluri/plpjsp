package com.cg.plp.bean;

public class UserBean
{
	private String userId=null;
	private String password=null;
	private String name=null;
	private String emailId=null;
	private String librarian=null;
	
	public String getUserId()
	{
		return userId;
	}
	public void setUserId(String userId)
	{
		this.userId = userId;
	}
	
	public String getPassword()
	{
		return password;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}
	
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	
	public String getEmailId()
	{
		return emailId;
	}
	public void setEmailId(String emailId)
	{
		this.emailId = emailId;
	}
	
	public String getLibrarian() 
	{
		return librarian;
	}
	public void setLibrarian(String librarian)
	{
		this.librarian = librarian;
	}	
	
}
