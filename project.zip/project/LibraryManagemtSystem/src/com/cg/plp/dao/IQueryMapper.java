package com.cg.plp.dao;

public interface IQueryMapper 
{
	public static final String getUserId="Select user_id_seq.nextval from dual";
	public static final String insertDetails="INSERT INTO Users values(?,?,?,?,?)";
	
	public static final String getPassword="SELECT password FROM Users WHERE user_id=?";
	public static final String checkUser="select librarian from Users where user_id=?";
	public static final String getUserName="Select user_name from Users WHERE user_id=?";
	public static final String insertBook="INSERT INTO BooksInventory VALUES (?,?,?,?,?,?,?)";
	public static final String getBooks="select * from BooksInventory order by book_id";
	public static final String deleteBook="DELETE FROM BooksInventory WHERE book_id=?";
	public static final String updateBookCopies="UPDATE BooksInventory SET no_of_copies=no_of_copies-? WHERE book_id=?";
	
	
	public static final String getBooksRegistered="select * from booksregistration where status=?";
	public static final String getNoOfCopies="select no_of_copies from BooksInventory where book_id=?";
	
	
	public static final String bookIssued="insert into BooksTransaction(transaction_id,registration_id,issue_date) values (transaction_seq.nextval,?,sysdate)";
	public static final String getTransactionId="select transaction_seq.currval from dual";
	
	public static final String setStatus="update BooksRegistration set status=? where registration_id=?";
	public static final String updateCopies="update BooksInventory set no_of_copies=no_of_copies-1 where book_id=?";
	public static final String selectCopies="SELECT no_of_copies FROM BooksInventory WHERE book_id=?";
	public static final String selectBookId="SELECT book_id FROM BooksRegistration WHERE user_id=?";
	public static final String selectStatus="SELECT status FROM BooksRegistration WHERE user_id=?";
	public static final String insertBookRegistration="INSERT INTO BooksRegistration (registration_id,book_id,user_id,registrationdate,status) VALUES(registration_seq.NEXTVAL,?,?,SYSDATE,?)";
	public static final String selectRegistrationId="SELECT registration_seq.CURRVAL FROM DUAL";
	public static final String selectBookRegistration="select registration_id,book_id,registrationdate from BooksRegistration WHERE user_id=? and status=? order by registration_id";
	public static final String returnedBookId="select Book_id from booksregistration where registration_id=?";
	public static final String getFine="select fine from bookstransaction where registration_id=?";
	public static final String setReturnDate="UPDATE BooksTransaction SET return_date=SYSDATE WHERE registration_id=?";
	public static final String setCopies="UPDATE BooksInventory SET no_of_copies=no_of_copies+1 where book_id=?";
	public static final String setReturnStatus="UPDATE BooksRegistration SET status=? WHERE registration_id=?";
	public static final String getDates="SELECT issue_date,return_date FROM BooksTransaction WHERE registration_id=?";
	public static final String updateFine="UPDATE BooksTransaction SET fine=? WHERE registration_id=?";
	
	
}
