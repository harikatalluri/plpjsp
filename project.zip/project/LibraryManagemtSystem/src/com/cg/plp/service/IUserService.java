package com.cg.plp.service;

import com.cg.plp.bean.UserBean;
import com.cg.plp.exception.LibraryException;

public interface IUserService 
{

	int isUserValid(String userId, String password) throws LibraryException; 

	String addDetails(UserBean userBean) throws LibraryException;

	String getUserName(String userId) throws LibraryException;
	
}
