package com.cg.plp.service;

import java.util.ArrayList;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookRegistrationBean;
import com.cg.plp.exception.LibraryException;
import com.cg.plp.exception.StudentException;

public interface IStudentService
{
	public ArrayList<BookBean> showBooks() throws LibraryException;

	public int isBookAvailable(String bookId) throws StudentException;

	public String addRequest(String userId, String bookId) throws StudentException;

	public ArrayList<BookRegistrationBean> showUserBooks(String userid) throws StudentException;

	public int returnBook(String transactionId, String bookId)  throws StudentException;
}
